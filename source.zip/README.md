# Cyber Onx V1 — Consent Diagnostic Edition

Versi ini sengaja dibuat sebagai panel diagnostik berbasis persetujuan.
Tidak ada phishing, pencurian password, pelacakan diam-diam, face capture,
atau pengambilan koordinat tanpa izin.

## Jalankan di Termux
1. Install Node.js: `pkg install nodejs`
2. Masuk folder proyek.
3. Jalankan: `node server.js`
4. Buka `http://127.0.0.1:3000`

Untuk geolocation browser, deploy dengan HTTPS pada domain yang kamu kontrol
atau jalankan di lingkungan yang menyediakan secure context.

Catatan:
- QRIS dan video menggunakan URL yang diberikan sebagai referensi.
- Pembayaran tidak diverifikasi otomatis oleh aplikasi ini.
- Upload bukti hanya disimpan sementara di server.
- Role/account pada versi ini adalah demo lokal; jangan gunakan password contoh
  untuk akun produksi.
