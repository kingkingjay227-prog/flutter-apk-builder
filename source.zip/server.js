const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 5 * 1024 * 1024 }
});

app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/diagnostic", (req,res)=>{
  // Data only arrives after the browser's explicit permission flow.
  const data = {
    receivedAt: new Date().toISOString(),
    consent: !!req.body.consent,
    device: req.body.device || {},
    location: req.body.location || null
  };
  if (!data.consent) return res.status(403).json({ok:false,error:"Consent required"});
  console.log("[CONSENT DIAGNOSTIC]", JSON.stringify(data));
  res.json({ok:true, message:"Diagnostic received with consent", data});
});

app.post("/api/payment-proof", upload.single("proof"), (req,res)=>{
  if (!req.file) return res.status(400).json({ok:false,error:"Proof file required"});
  res.json({
    ok:true,
    status:"pending_review",
    filename:req.file.filename,
    originalName:req.file.originalname,
    receivedAt:new Date().toISOString()
  });
});

app.listen(PORT, ()=>console.log(`Cyber Onx V1 running at http://127.0.0.1:${PORT}`));
