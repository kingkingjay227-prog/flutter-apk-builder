CYBER ONX V1 — CONSENT EDITION
Run: npm install express
Then: node server.js
Open: http://localhost:3000

GPS nyata hanya setelah pengguna membuka link dan memberikan permission browser.
Maksimal 20 log lokasi ditampilkan.
Phishing credential, token TikTok/WhatsApp, kamera/wajah tersembunyi, dan pelacakan
nomor telepon tidak dibuat.

Developer demo lokal: username Alip, password default 1234. Jangan gunakan default ini
di server publik; gunakan environment variable DEVELOPER_PASSWORD dan authentication aman.

Video intro menggunakan URL yang diberikan pengguna. HTTPS diperlukan untuk geolocation
pada deployment internet.
