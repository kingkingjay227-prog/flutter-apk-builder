const logs=[];
const accounts=JSON.parse(localStorage.getItem("onx_accounts")||"[]");

function log(x){logs.unshift(new Date().toLocaleString()+" — "+x);document.getElementById("logsOut").textContent=logs.join("\n")}
function enterApp(){document.getElementById("intro").classList.add("hidden");document.getElementById("app").classList.remove("hidden");log("Panel dibuka");}
setTimeout(()=>{if(!document.getElementById("intro").classList.contains("hidden")) enterApp()},6500);

function showTab(id){document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));document.getElementById(id).classList.add("active")}

function createConsentLink(){
  const url=location.origin+location.pathname+"?consent=1";
  document.getElementById("consentLink").textContent=url+"\n\nLink ini hanya membuka halaman yang meminta izin. Tidak ada pengambilan data tersembunyi.";
  navigator.clipboard?.writeText(url).catch(()=>{});
  log("Halaman persetujuan dibuat");
}

async function runDiagnostic(){
  if(!document.getElementById("consent").checked){alert("Centang persetujuan terlebih dahulu.");return}
  const bar=document.querySelector("#progress span");bar.style.width="0%";
  const result=document.getElementById("result"); result.textContent="Meminta izin browser...";
  for(let i=1;i<=5;i++){await new Promise(r=>setTimeout(r,350));bar.style.width=(i*20)+"%"}
  const device={
    userAgent:navigator.userAgent,
    platform:navigator.platform,
    language:navigator.language,
    screen:`${screen.width}x${screen.height}`,
    online:navigator.onLine,
    timezone:Intl.DateTimeFormat().resolvedOptions().timeZone
  };
  navigator.geolocation.getCurrentPosition(async pos=>{
    const location={latitude:pos.coords.latitude,longitude:pos.coords.longitude,accuracy:pos.coords.accuracy};
    result.textContent=JSON.stringify({consent:true,device,location},null,2);
    try{
      const r=await fetch("/api/diagnostic",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({consent:true,device,location})});
      const j=await r.json(); log("Diagnostik diterima setelah izin lokasi");
    }catch(e){log("Data tampil lokal; server tidak tersedia")}
  },err=>{
    result.textContent=JSON.stringify({consent:true,device,location:null,note:"Lokasi tidak diberikan atau izin ditolak."},null,2);
    log("Diagnostik selesai tanpa lokasi");
  },{enableHighAccuracy:true,timeout:10000,maximumAge:0});
}

let selected=null;
function selectPlan(role,price){selected={role,price};document.getElementById("selectedPlan").textContent=`Dipilih: ${role} — Rp${price.toLocaleString("id-ID")} | Status: menunggu bukti` ;log(`Paket ${role} dipilih`)}
document.getElementById("proofForm").addEventListener("submit",async e=>{
  e.preventDefault();if(!selected){alert("Pilih paket dulu.");return}
  const fd=new FormData(e.target);fd.append("role",selected.role);fd.append("price",selected.price);
  try{const r=await fetch("/api/payment-proof",{method:"POST",body:fd});const j=await r.json();document.getElementById("paymentStatus").textContent="Bukti diterima — status: MENUNGGU REVIEW ADMIN.";log("Bukti pembayaran diunggah");}
  catch(e){document.getElementById("paymentStatus").textContent="Mode offline: bukti belum dikirim ke server."}
});

function renderAccounts(){const el=document.getElementById("accountsList");el.innerHTML="";accounts.forEach((a,i)=>{const d=document.createElement("div");d.className="account";d.innerHTML=`<span><b>${a.user}</b> — ${a.role}<br><small>Aktif sampai: ${a.until||"tidak ditentukan"}</small></span><button onclick="delAccount(${i})">DELETE</button>`;el.appendChild(d)})}
function addAccount(){const user=document.getElementById("newUser").value.trim(),role=document.getElementById("newRole").value,until=document.getElementById("activeUntil").value;if(!user){alert("Username wajib diisi.");return}accounts.push({user,role,until});localStorage.setItem("onx_accounts",JSON.stringify(accounts));renderAccounts();log(`Akun ${role} dibuat: ${user}`)}
function delAccount(i){const a=accounts[i];if(!confirm("Hapus akun "+a.user+"?"))return;accounts.splice(i,1);localStorage.setItem("onx_accounts",JSON.stringify(accounts));renderAccounts();log(`Akun dihapus: ${a.user}`)}
renderAccounts();

if(new URLSearchParams(location.search).get("consent")==="1"){
  setTimeout(()=>{enterApp();showTab("home")},100);
}
